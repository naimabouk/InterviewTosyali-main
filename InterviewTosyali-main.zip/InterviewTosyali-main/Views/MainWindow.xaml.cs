﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using HtmlAgilityPack;

namespace JobInterview.Views
{
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }

        

       

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
        }
    }
}